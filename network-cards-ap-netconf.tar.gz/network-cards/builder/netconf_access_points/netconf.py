"""Minimal NETCONF client for the Catalyst 9800, over paramiko.

NETCONF is RPC-over-SSH: connect to the `netconf` subsystem (TCP 830), exchange
`<hello>`, then send `<rpc>` documents and read `<rpc-reply>` documents back.
Only reads (`<get>`) are performed.

Two deliberate simplifications:

* **We advertise only `base:1.0`.** RFC 6242 chunked framing is used only when
  BOTH ends offer `:base:1.1`, so advertising 1.0 alone forces the simple
  `]]>]]>` end-of-message delimiter. That removes the chunk-framing edge cases
  that make hand-rolled NETCONF clients flaky, and IOS-XE supports 1.0 fine.
* **This module returns the reply XML as a string.** All parsing lives in
  extract.py, which keeps the transport dumb and means `--dump` writes exactly
  what the controller sent — the thing you need to pin leaf paths.

`import paramiko` is deferred into the connect path so `build_aps.py --selftest`
still runs on a host that has never installed it. paramiko is this project's one
third-party dependency (RULES.md §1).
"""

import time
import xml.etree.ElementTree as ET

NETCONF_PORT = 830
DEFAULT_TIMEOUT = 60.0
DELIM = b"]]>]]>"
BASE_1_0 = "urn:ietf:params:xml:ns:netconf:base:1.0"

CLIENT_HELLO = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    f'<hello xmlns="{BASE_1_0}">'
    "<capabilities>"
    f"<capability>{BASE_1_0}</capability>"
    "</capabilities>"
    "</hello>"
)

# Same YANG models RESTCONF exposed — NETCONF differs only in transport/encoding.
WIRELESS_NS = "http://cisco.com/ns/yang/Cisco-IOS-XE-wireless-access-point-oper"
NATIVE_NS = "http://cisco.com/ns/yang/Cisco-IOS-XE-native"

# Two narrow subtree filters rather than one `access-point-oper-data` fetch: the
# whole container drags in per-radio statistics and is very large on a populated
# controller.
CAPWAP_FILTER = (f'<access-point-oper-data xmlns="{WIRELESS_NS}">'
                 "<capwap-data/></access-point-oper-data>")
CDP_FILTER = (f'<access-point-oper-data xmlns="{WIRELESS_NS}">'
              "<cdp-cache-data/></access-point-oper-data>")
HOSTNAME_FILTER = f'<native xmlns="{NATIVE_NS}"><hostname/></native>'


class NetconfError(Exception):
    """Any failure connecting to or driving a controller's NETCONF interface."""


def _import_paramiko():
    try:
        import paramiko
    except ImportError as e:
        raise NetconfError(
            "paramiko is not installed — run: python3 -m pip install paramiko"
        ) from e
    return paramiko


def localname(tag):
    """'{urn:...}rpc-error' -> 'rpc-error'. NETCONF XML is namespace-heavy."""
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def find_all(elem, name):
    """Every descendant (and self) whose local name matches, namespace ignored."""
    out = []
    if localname(elem.tag) == name:
        out.append(elem)
    for child in elem.iter():
        if child is not elem and localname(child.tag) == name:
            out.append(child)
    return out


def check_rpc_error(reply_xml):
    """Raise NetconfError if the reply carries an <rpc-error>."""
    try:
        root = ET.fromstring(reply_xml)
    except ET.ParseError as e:
        raise NetconfError(f"reply was not well-formed XML: {e}") from e
    errors = find_all(root, "rpc-error")
    if not errors:
        return root
    parts = []
    for err in errors:
        bits = {localname(c.tag): (c.text or "").strip() for c in err}
        parts.append(bits.get("error-message")
                     or bits.get("error-tag")
                     or "unspecified rpc-error")
    raise NetconfError("controller returned rpc-error: " + "; ".join(parts))


class NetconfSession:
    """One NETCONF session against one controller. Use as a context manager."""

    def __init__(self, host, username, password=None, port=NETCONF_PORT,
                 key_filename=None, timeout=DEFAULT_TIMEOUT):
        self.host = host
        self.username = username
        self.password = password or None
        self.port = int(port or NETCONF_PORT)
        self.key_filename = key_filename or None
        self.timeout = float(timeout)
        self._client = None
        self._chan = None
        self._msg_id = 0
        self.server_capabilities = []

    # -- lifecycle ---------------------------------------------------------
    def open(self):
        paramiko = _import_paramiko()
        client = paramiko.SSHClient()
        # Lab-grade host-key handling, same as the SSH builder. Tighten to a
        # known_hosts policy before using this beyond a controlled test.
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(
                self.host, port=self.port, username=self.username,
                password=self.password, key_filename=self.key_filename,
                timeout=self.timeout, banner_timeout=self.timeout,
                auth_timeout=self.timeout,
                look_for_keys=False, allow_agent=False,
            )
            chan = client.get_transport().open_session()
            chan.settimeout(self.timeout)
            chan.invoke_subsystem("netconf")
        except Exception as e:
            try:
                client.close()
            except Exception:
                pass
            raise NetconfError(self._connect_hint(e)) from e

        self._client, self._chan = client, chan
        # Send ours first, then read theirs — some servers wait for the client
        # hello before speaking, and sending first can never deadlock.
        self._send(CLIENT_HELLO)
        hello = self._read_message()
        root = check_rpc_error(hello)
        self.server_capabilities = [
            (c.text or "").strip() for c in find_all(root, "capability")]
        if not self.server_capabilities:
            raise NetconfError(
                f"{self.host}: no NETCONF <hello> from the server — is this "
                f"really the netconf subsystem on port {self.port}?")
        return self

    def _connect_hint(self, e):
        name = type(e).__name__
        msg = f"{self.host}:{self.port}: {name}: {e}"
        if "Authentication" in name:
            return (f"{msg} — check username/password (or key_filename) and that "
                    f"the account may open the netconf subsystem")
        if isinstance(e, (ConnectionRefusedError, OSError)) and "refused" in str(e).lower():
            return (f"{msg} — nothing listening on {self.port}; enable "
                    f"`netconf-yang` on the controller and check the ACL/firewall")
        if "timed out" in str(e).lower() or name in ("timeout", "TimeoutError"):
            return (f"{msg} — no answer on {self.port}; check reachability and "
                    f"that `netconf-yang` is running")
        return msg

    def close(self):
        for obj in (self._chan, self._client):
            try:
                if obj is not None:
                    obj.close()
            except Exception:
                pass
        self._chan = self._client = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *exc):
        self.close()
        return False

    # -- wire --------------------------------------------------------------
    def _send(self, doc):
        try:
            self._chan.sendall(doc.encode("utf-8") + DELIM)
        except Exception as e:
            raise NetconfError(f"{self.host}: send failed: {e}") from e

    def _read_message(self):
        """Read one NETCONF message, up to the ]]>]]> delimiter.

        The delimiter routinely straddles a recv() boundary, so the search runs
        over the accumulated buffer — but only across the newly-arrived tail plus
        an overlap, so a multi-megabyte reply doesn't turn into O(n^2) scanning.
        """
        buf = bytearray()
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            if self._chan.recv_ready():
                try:
                    chunk = self._chan.recv(65536)
                except Exception as e:
                    raise NetconfError(f"{self.host}: read failed: {e}") from e
                if not chunk:
                    break
                start = max(0, len(buf) - len(DELIM) + 1)
                buf += chunk
                idx = buf.find(DELIM, start)
                if idx >= 0:
                    return buf[:idx].decode("utf-8", "replace")
                deadline = time.monotonic() + self.timeout  # progress: extend
            elif self._chan.closed:
                break
            else:
                time.sleep(0.02)
        if buf:
            raise NetconfError(
                f"{self.host}: incomplete reply ({len(buf)} bytes, no ]]>]]> "
                f"terminator within {self.timeout}s)")
        raise NetconfError(f"{self.host}: no reply within {self.timeout}s")

    # -- rpc ---------------------------------------------------------------
    def rpc(self, body):
        """Send one <rpc> and return the raw <rpc-reply> XML string."""
        if self._chan is None:
            raise NetconfError(f"{self.host}: session is not open")
        self._msg_id += 1
        doc = ('<?xml version="1.0" encoding="UTF-8"?>'
               f'<rpc message-id="{self._msg_id}" xmlns="{BASE_1_0}">'
               f"{body}</rpc>")
        self._send(doc)
        reply = self._read_message()
        check_rpc_error(reply)
        return reply

    def get(self, filter_xml):
        """<get> with a subtree filter. Returns the raw reply XML string."""
        return self.rpc(f'<get><filter type="subtree">{filter_xml}</filter></get>')

    def get_hostname(self):
        """The controller's configured hostname, for the card's `wlc` field.

        Best-effort: reading `native` config needs more privilege than the oper
        data, so fall back to the configured host rather than failing the run.
        """
        try:
            reply = self.get(HOSTNAME_FILTER)
            root = ET.fromstring(reply)
        except (NetconfError, ET.ParseError):
            return ""
        for el in find_all(root, "hostname"):
            if el.text and el.text.strip():
                return el.text.strip()
        return ""


def data_is_empty(reply_xml):
    """True when <data/> came back with no children — usually a filter whose
    namespace doesn't match this IOS-XE version, not an empty fleet."""
    try:
        root = ET.fromstring(reply_xml)
    except ET.ParseError:
        return False
    for data in find_all(root, "data"):
        return len(list(data)) == 0
    return True

